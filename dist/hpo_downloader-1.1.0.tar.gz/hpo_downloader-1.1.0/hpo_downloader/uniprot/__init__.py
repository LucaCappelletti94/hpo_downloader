from .uniprot_mapping import uniprot_mapping

__all__ = [
    "uniprot_mapping"
]
