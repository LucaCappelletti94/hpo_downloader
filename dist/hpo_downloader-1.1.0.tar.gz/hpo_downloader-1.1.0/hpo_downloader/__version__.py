"""Current version of package hpo_downloader"""
__version__ = "1.1.0"
