"""Current version of package hpo_downloader"""
__version__ = "1.0.0"